﻿using Fme.Library.Enums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Runtime.Serialization;
using System.Linq;
using System.Globalization;
using System.Reflection;

namespace Fme.Library.Comparison
{
    public class GenericConverter<T>
    {
        public static string Token = "|";
        
        /// <summary>
        /// Joins the specified items.
        /// </summary>
        /// <param name="items">The items.</param>
        /// <returns>System.String.</returns>
        protected string Join(T[] items)
        {
            return string.Join(Token, items);
        }

        /// <summary>
        /// Splits the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.String[].</returns>
        protected string[] Split(string value)
        {
            return value.Split(new string[] { Token }, StringSplitOptions.RemoveEmptyEntries).ToArray();
        }

        /// <summary>
        /// Converts the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>T.</returns>
        public T Convert(string value)
        {
            FormatterConverter converter = new FormatterConverter();
            return (T)converter.Convert(value, typeof(T));
        }
        /// <summary>
        /// Converts the specified values.
        /// </summary>
        /// <param name="values">The values.</param>
        /// <returns>List&lt;T&gt;.</returns>
        public List<T> Convert(string[] values)
        {
            FormatterConverter converter = new FormatterConverter();
            List<T> items = new List<T>();
            foreach (var value in values)
                items.Add((T)converter.Convert(value, typeof(T)));
            return items;
        }
        /// <summary>
        /// Joins the specified values.
        /// </summary>
        /// <param name="values">The values.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>System.String.</returns>
        public string Join(T[] values, Func<T,T> selector)
        {
            List<T> items = new List<T>();
            values.ToList().ForEach(value => items.Add(selector(value)));
            return Join(items.OrderBy(o => o).ToArray());
        }
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="selector">The selector.</param>
        /// <returns>System.String.</returns>
        public string Transform(string value, Func<T,T> selector)
        {
            string[] values = Split(value);
            List<T> converts = (List<T>)Convert(values);
            return Join(converts.ToArray(), selector);
        }

        /// <summary>
        /// Compares the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="selector">The selector.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Compare(T value, Func<T, bool> selector)
        {
            return selector(value);
         //  return  value.CompareTo(selector);
          //  return selector(value);
        }
    }
    public class StringConverter :GenericConverter<string>
    {
        /// <summary>
        /// Joins the specified values.
        /// </summary>
        /// <param name="values">The values.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public string Join(string[] values, int offset)
        {
            return base.Join(values, (value) => value);
        }
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public string Transform(string value, int offset)
        {
            return base.Transform(value, (dt) => dt);
        }
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="translate">The translate.</param>
        /// <returns>System.String.</returns>
        public string Transform(string value, Dictionary<string,string> translate)
        {

            return base.Transform(value, (dt) => translate.ContainsKey(dt) ? translate[dt] : dt);
        }
        /// <summary>
        /// Startses the width.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool StartsWith(string value1, string value2)
        {
           return base.Compare(value1, (x) => x.StartsWith(value2));
        }

        /// <summary>
        /// Endses the with.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool EndsWith(string value1, string value2)
        {
            return base.Compare(value1, (x) => x.EndsWith(value2));
        }

        /// <summary>
        /// Determines whether [contains] [the specified value1].
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns><c>true</c> if [contains] [the specified value1]; otherwise, <c>false</c>.</returns>
        public bool Contains(string value1, string value2)
        {
            return base.Compare(value1, (x) => x.Contains(value2));
        }
        /// <summary>
        /// Equalses the specified value1.
        /// </summary>
        /// <param name="value1">The value1.</param>
        /// <param name="value2">The value2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool Equals(string value1, string value2)
        {
            return base.Compare(value1, (x) => x.Equals(value2));
        }
    }
    public class DateConverter : DateTimeConverter
    {
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public override string Transform(string value, int offset)
        {
            return base.Transform(value, (dt) =>  dt.AddHours(offset).Date);
        }
    }
    public class DateTimeConverter : GenericConverter<DateTime>
    {       
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public virtual string Transform(string value, int offset)
        {
           return base.Transform(value, (dt) => dt.AddHours(offset));            
        }
    }
    public class BooleanConverter : GenericConverter<bool>
    {
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public virtual string Transform(string value, int offset)
        {
            return base.Transform(value, (dt) => ToBoolean(dt));
        }

        /// <summary>
        /// To the integer.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Int32.</returns>
        private bool ToBoolean(bool value)
        {
            return (bool)System.Convert.ChangeType(value, typeof(bool));
        }
    }
    public class IntegerConverter : GenericConverter<int>
    {
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public string Transform(string value, int offset)
        {
            string[] values = Split(value);
            List<int> converts = new List<int>();

            values.ToList().ForEach(item => converts.Add(ToInteger(item)));            
            return Join(converts.ToArray());
        }              
              
        /// <summary>
        /// To the integer.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Int32.</returns>
        public static int ToInteger(object value)
        {
            return (int)Math.Floor((float)System.Convert.ChangeType(value, typeof(float)));
        }
    }        
    public class FloatConverter : GenericConverter<float>
    {
        /// <summary>
        /// Transforms the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="offset">The offset.</param>
        /// <returns>System.String.</returns>
        public virtual string Transform(string values, int offset)
        {
            return base.Transform(values, (value) => ToFloat(value));            
        }
        /// <summary>
        /// To the float.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Single.</returns>
        public static float ToFloat(object value)
        {
            return (float)System.Convert.ChangeType(value, typeof(float));
        }
    }





    /// <summary>
    /// Class GenericCompare.
    /// </summary>
    /// <seealso cref="System.Collections.Generic.Dictionary{Fme.Library.Enums.ComparisonTypeEnum, System.Func{System.String, System.String, Fme.Library.Enums.OperatorEnums, System.Object, System.Object, System.Boolean}}" />
    public class GenericCompare : Dictionary<ComparisonTypeEnum, Func<string, string, OperatorEnums, object, object, object, object, bool>>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GenericCompare"/> class.
        /// </summary>
        public GenericCompare()
        {
            Add(ComparisonTypeEnum.Date, (left, right, ops, parm1, parm2, parm3, parm4) => 
                CompareDate(left, right, ops, (int)parm1, (int)parm2));

            Add(ComparisonTypeEnum.Datetime, (left, right, ops, parm1, parm2, parm3, parm4) =>
               CompareDateTime(left, right, ops, (int)parm1, (int)parm2));

            Add(ComparisonTypeEnum.String, (left, right, ops, parm1, parm2, parm3, parm4) =>
              CompareString(left, right, ops, (Dictionary<string,string>)parm3, (Dictionary<string,string>)parm4));

            Add(ComparisonTypeEnum.Integer, (left, right, ops, parm1, parm2, parm3, parm4) =>
                CompareInteger(left, right, ops, (int)parm1, (int)parm2));

            Add(ComparisonTypeEnum.Float, (left, right, ops, parm1, parm2, parm3, parm4) =>
                CompareInteger(left, right, ops, (int)parm1, (int)parm2));

            Add(ComparisonTypeEnum.Boolean, (left, right, ops, parm1, parm2, parm3, parm4) =>
              CompareInteger(left, right, ops, (int)parm1, (int)parm2));
            
        }
        
        /// <summary>
        /// Compares the date time.
        /// </summary>
        /// <param name="left">The left.</param>
        /// <param name="right">The right.</param>
        /// <param name="ops">The ops.</param>
        /// <param name="offset1">The offset1.</param>
        /// <param name="offset2">The offset2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool CompareDateTime(string left, string right, OperatorEnums ops,  int offset1, int offset2)
        {
            if (ops == OperatorEnums.Equals)
            {
                var x = new DateTimeConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.CompareTo(r) == 0;  // x.Equals(l, r);
            }
            if (ops == OperatorEnums.Contains)
            {
                var x = new DateTimeConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.Contains(r);  // x.Equals(l, r);
            }
            if (ops == OperatorEnums.StartsWidth)
            {
                var x = new DateTimeConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.StartsWith(r);  // x.Equals(l, r);
            }
            if (ops == OperatorEnums.EndsWidth)
            {
                var x = new DateTimeConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.EndsWith(r);  // x.Equals(l, r);
            }
            return false;
        }
        
        /// <summary>
        /// Compares the date.
        /// </summary>
        /// <param name="left">The left.</param>
        /// <param name="right">The right.</param>
        /// <param name="ops">The ops.</param>
        /// <param name="offset1">The offset1.</param>
        /// <param name="offset2">The offset2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool CompareDate(string left, string right, OperatorEnums ops, int offset1, int offset2)
        {
            var x = new DateConverter();
            var l = x.Transform(left, offset1);
            var r = x.Transform(right, offset2);

            Type type = l.GetType();
            MethodInfo method = l.GetType().GetMethods().
                Where(w => w.Name == Enum.GetName(typeof(OperatorEnums), ops)).FirstOrDefault();

            return (bool)method.Invoke(l, new object[] { r });
            

            if (ops == OperatorEnums.Equals)
            {               
                return l.CompareTo(r) == 0;
            }
            if (ops == OperatorEnums.Contains)
            {             
                return l.Contains(r);
            }
            if(ops == OperatorEnums.StartsWidth)
            {              
                return l.StartsWith(r);
            }
            if (ops == OperatorEnums.EndsWidth)
            {              
                return l.EndsWith(r);
            }
            return false;

        }

        /// <summary>
        /// Compares the integer.
        /// </summary>
        /// <param name="left">The left.</param>
        /// <param name="right">The right.</param>
        /// <param name="ops">The ops.</param>
        /// <param name="offset1">The offset1.</param>
        /// <param name="offset2">The offset2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool CompareInteger(string left, string right, OperatorEnums ops, int offset1, int offset2)
        {
            
            if (ops == OperatorEnums.Equals)
            {
                var x = new IntegerConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.CompareTo(r) == 0;
            }
            if (ops == OperatorEnums.Contains)
            {
                var x = new IntegerConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.Contains(r);
            }
            if (ops == OperatorEnums.StartsWidth)
            {
                var x = new IntegerConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.StartsWith(r);
            }
            if (ops == OperatorEnums.EndsWidth)
            {
                var x = new IntegerConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.EndsWith(r);
            }
            return false;

        }

        /// <summary>
        /// Compares the float.
        /// </summary>
        /// <param name="left">The left.</param>
        /// <param name="right">The right.</param>
        /// <param name="ops">The ops.</param>
        /// <param name="offset1">The offset1.</param>
        /// <param name="offset2">The offset2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool CompareFloat(string left, string right, OperatorEnums ops, int offset1, int offset2)
        {

            if (ops == OperatorEnums.Equals)
            {
                var x = new FloatConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.CompareTo(r) == 0;
            }
            if (ops == OperatorEnums.Contains)
            {
                var x = new FloatConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.Contains(r);
            }
            if (ops == OperatorEnums.StartsWidth)
            {
                var x = new FloatConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.StartsWith(r);
            }
            if (ops == OperatorEnums.EndsWidth)
            {
                var x = new FloatConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.EndsWith(r);
            }
            return false;

        }

        /// <summary>
        /// Compares the boolean.
        /// </summary>
        /// <param name="left">The left.</param>
        /// <param name="right">The right.</param>
        /// <param name="ops">The ops.</param>
        /// <param name="offset1">The offset1.</param>
        /// <param name="offset2">The offset2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool CompareBoolean(string left, string right, OperatorEnums ops, int offset1, int offset2)
        {

            if (ops == OperatorEnums.Equals)
            {
                var x = new BooleanConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.CompareTo(r) == 0;
            }
            if (ops == OperatorEnums.Contains)
            {
                var x = new BooleanConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.Contains(r);
            }
            if (ops == OperatorEnums.StartsWidth)
            {
                var x = new BooleanConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.StartsWith(r);
            }
            if (ops == OperatorEnums.EndsWidth)
            {
                var x = new BooleanConverter();
                var l = x.Transform(left, offset1);
                var r = x.Transform(right, offset2);
                return l.EndsWith(r);
            }
            return false;

        }

        /// <summary>
        /// Compares the string.
        /// </summary>
        /// <param name="left">The left.</param>
        /// <param name="right">The right.</param>
        /// <param name="ops">The ops.</param>
        /// <param name="translate1">The translate1.</param>
        /// <param name="translate2">The translate2.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool CompareString(string left, string right, OperatorEnums ops,  Dictionary<string,string> translate1, Dictionary<string, string> translate2)
        {
            if (ops == OperatorEnums.Equals)
            {
                var x = new StringConverter();
                var l = x.Transform(left, translate1);
                var r = x.Transform(right, translate2);
                return l.Equals(r);
            }
            if (ops == OperatorEnums.StartsWidth)
            {
                var x = new StringConverter();
                var l = x.Transform(left, translate1);
                var r = x.Transform(right, translate2);
                return l.StartsWith(r);
            }
            if (ops == OperatorEnums.EndsWidth)
            {
                var x = new StringConverter();
                var l = x.Transform(left, translate1);
                var r = x.Transform(right, translate2);
                return l.EndsWith(r);
            }
            if (ops == OperatorEnums.Contains)
            {
                var x = new StringConverter();
                var l = x.Transform(left, translate1);
                var r = x.Transform(right, translate2);
                return l.Contains(r);
            }
            return false;
        }
        
        
    }
   
   
}
